package MadreSelvaCosmetics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MadreSelvaCosmeticsApplicationTests {

    @Test
    void contextLoads() {
    }

}
